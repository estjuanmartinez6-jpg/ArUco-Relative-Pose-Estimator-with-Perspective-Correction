
import sys
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Pose2D
from cv_bridge import CvBridge
import cv2
import cv2.aruco as aruco
import numpy as np
import math
import requests
import threading
import time

class MJPEGClient:
    """
    Lector robusto de streams MJPEG vía HTTP.
    Corre en un hilo y mantiene self.frame (BGR numpy) con el último JPEG decodificado.
    """
    def __init__(self, url, reconnect_delay=1.0, timeout=10.0):
        self.url = url
        self.reconnect_delay = reconnect_delay
        self.timeout = timeout
        self._thread = None
        self._stop_event = threading.Event()
        self._frame_lock = threading.Lock()
        self.frame = None  # numpy BGR
        self._running = False

    def start(self):
        if self._thread and self._thread.is_alive():
            return
        self._stop_event.clear()
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()
        self._running = True

    def stop(self):
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=1.0)
        self._running = False

    def _run(self):
        while not self._stop_event.is_set():
            try:
                with requests.get(self.url, stream=True, timeout=self.timeout) as r:
                    if r.status_code != 200:
                        time.sleep(self.reconnect_delay)
                        continue

                    buff = b''
                    for chunk in r.iter_content(chunk_size=1024):
                        if self._stop_event.is_set():
                            break
                        if not chunk:
                            continue
                        buff += chunk
                        while True:
                            soi = buff.find(b'\xff\xd8')
                            if soi == -1:
                                break
                            eoi = buff.find(b'\xff\xd9', soi + 2)
                            if eoi == -1:
                                if len(buff) > 5_000_000:
                                    buff = buff[soi:]
                                break
                            jpg = buff[soi:eoi + 2]
                            buff = buff[eoi + 2:]
                            arr = np.frombuffer(jpg, dtype=np.uint8)
                            img = cv2.imdecode(arr, cv2.IMREAD_COLOR)
                            if img is not None:
                                with self._frame_lock:
                                    self.frame = img
            except (requests.exceptions.RequestException, Exception):
                time.sleep(self.reconnect_delay)
                continue

    def get_frame(self):
        with self._frame_lock:
            if self.frame is None:
                return None
            return self.frame.copy()


class ArucoCamPose2DNode(Node):
    """
    Nodo que publica geometry_msgs/Pose2D en /aruco/pose2d con:
      - x, y: posición del marcador derecho relativa al marcador izquierdo (m)
      - theta: diferencia angular yaw_right - yaw_left (rad, normalizado)
    Publica a 10 Hz; si no hay 2 marcadores re-publica el último valor válido.
    """
    def __init__(self):
        super().__init__('aruco_pose2d_node')

        # Publisher único: Pose2D con x,y,theta (theta en radianes)
        self.publisher_pose2d = self.create_publisher(Pose2D, 'aruco/pose2d', 10)

        # Timer: 0.1s => 10 Hz
        self.timer_period = 0.1
        self.timer = self.create_timer(self.timer_period, self.timer_callback)

        # CV bridge (por si quieres exportar imágenes; no es obligatorio)
        self.bridge = CvBridge()

        # URL de la cámara IP
        self.url = "http://192.168.1.66:8080/video"

        # Cliente MJPEG robusto
        self.mjpeg = MJPEGClient(self.url, reconnect_delay=1.0, timeout=10.0)
        self.mjpeg.start()
        self.get_logger().info(f"Iniciando lector MJPEG para {self.url}")

        # ArUco
        self.aruco_dict = aruco.Dictionary_get(aruco.DICT_4X4_50)
        self.aruco_params = aruco.DetectorParameters_create()

        # Parámetros de cámara (reemplaza con calibración real)
        self.camera_matrix = np.array([[800.0,   0.0, 320.0],
                                       [  0.0, 800.0, 240.0],
                                       [  0.0,   0.0,   1.0]], dtype=np.float64)
        self.dist_coeffs = np.zeros((5, 1), dtype=np.float64)
        self.marker_length_m = 0.1

        # Último valor relativo válido (x, y, yaw)
        self.last_rel_x = 0.0
        self.last_rel_y = 0.0
        self.last_rel_yaw = 0.0
        self.has_valid_detection = False
        
        # Marcador de referencia (el primero detectado o el de menor ID)
        self.reference_marker_id = None

    def timer_callback(self):
        # Obtener último frame desde MJPEGClient
        frame = self.mjpeg.get_frame()
        if frame is None:
            self.get_logger().debug("No hay frame aún; re-publicando último valor conocido.")
            self._publish_pose2d(self.last_rel_x, self.last_rel_y, self.last_rel_yaw)
            return

        # Crear copia para dibujar
        display_frame = frame.copy()

        # Procesar frame
        try:
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        except Exception as e:
            self.get_logger().warn(f"Error convert to gray: {e}; re-publicando último valor")
            self._publish_pose2d(self.last_rel_x, self.last_rel_y, self.last_rel_yaw)
            self._show_frame(display_frame, 0, [])
            return

        corners, ids, _ = aruco.detectMarkers(gray, self.aruco_dict, parameters=self.aruco_params)

        # Número de marcadores detectados
        num_markers = 0 if ids is None else len(ids)
        ids_list = [] if ids is None else [int(i[0]) if isinstance(i, (list, np.ndarray)) else int(i) for i in ids]

        # Dibujar marcadores detectados en el frame
        if ids is not None and len(ids) > 0:
            aruco.drawDetectedMarkers(display_frame, corners, ids)

        # Establecer marcador de referencia
        if num_markers >= 1:
            if self.reference_marker_id is None:
                # Si aún no hay referencia, tomar el primero detectado
                self.reference_marker_id = ids_list[0]
                self.get_logger().info(f"Marcador de referencia establecido: ID={self.reference_marker_id}")
            elif num_markers >= 2:
                # Si hay 2+ marcadores, asegurar que la referencia sea el de menor ID
                min_id = min(ids_list)
                if min_id < self.reference_marker_id:
                    self.reference_marker_id = min_id
                    self.get_logger().info(f"Marcador de referencia actualizado a menor ID: {self.reference_marker_id}")
        
        # Procesar solo si hay 2 o más marcadores
        if num_markers < 2:
            if not self.has_valid_detection:
                self.get_logger().debug(f"Detectados {num_markers} marcador(es); se necesitan 2. Publicando ceros.")
            else:
                self.get_logger().debug(f"Detectados {num_markers} marcador(es); re-publicando último valor válido.")
            self._publish_pose2d(self.last_rel_x, self.last_rel_y, self.last_rel_yaw)
            self._show_frame(display_frame, num_markers, ids_list)
            return

        # Estimar pose de cada marcador
        rvecs, tvecs, _ = aruco.estimatePoseSingleMarkers(corners, self.marker_length_m,
                                                          self.camera_matrix, self.dist_coeffs)

        N = len(ids)
        rvecs_np = np.reshape(rvecs, (N, 3))
        tvecs_np = np.reshape(tvecs, (N, 3))

        # Selección del marcador de referencia y el otro
        # Referencia: el marcador guardado (primero detectado o menor ID)
        # Otro: cualquier otro marcador detectado
        
        # Buscar índice del marcador de referencia
        ref_idx = None
        other_idx = None
        
        for i, marker_id in enumerate(ids_list):
            if marker_id == self.reference_marker_id:
                ref_idx = i
            elif other_idx is None:
                other_idx = i
        
        # Si no encontramos la referencia (no debería pasar), usar el de menor ID
        if ref_idx is None:
            ref_idx = ids_list.index(min(ids_list))
            self.reference_marker_id = ids_list[ref_idx]
        
        # Si no hay otro marcador, salir
        if other_idx is None:
            if ref_idx == 0 and len(ids_list) > 1:
                other_idx = 1
            else:
                other_idx = 0 if ref_idx != 0 else 1
        
        ref_id = ids_list[ref_idx]
        other_id = ids_list[other_idx]

        t_ref = tvecs_np[ref_idx].reshape(3,)
        rvec_ref = rvecs_np[ref_idx].reshape(3,)
        R_ref, _ = cv2.Rodrigues(rvec_ref)

        t_other = tvecs_np[other_idx].reshape(3,)
        rvec_other = rvecs_np[other_idx].reshape(3,)
        R_other, _ = cv2.Rodrigues(rvec_other)

        # Transformación: coordenadas del otro marcador en el sistema de referencia
        # t_rel representa la posición del 'other' visto desde el sistema de coordenadas de 'ref'
        delta_t = t_other - t_ref  # Vector de referencia a otro en coords de cámara
        t_rel = R_ref.T.dot(delta_t)    # Transformar al sistema de coordenadas de ref
        R_rel = R_ref.T.dot(R_other)

        rel_x = float(t_rel[0])
        rel_y = float(t_rel[1])
        rel_z = float(t_rel[2])

        # Extraer y calcular diferencia de yaw
        roll_ref, pitch_ref, yaw_ref = self.rotation_matrix_to_euler(R_ref)   # rad
        roll_other, pitch_other, yaw_other = self.rotation_matrix_to_euler(R_other)  # rad
        yaw_diff = ( yaw_other - yaw_ref)
        yaw_diff = math.atan2(math.sin(yaw_diff), math.cos(yaw_diff))  # normalizar

        # Guardar último valor válido
        self.last_rel_x = rel_x
        self.last_rel_y = rel_y
        self.last_rel_yaw = yaw_diff
        self.has_valid_detection = True

        # Publicar Pose2D (x,y,theta)
        self._publish_pose2d(rel_x, rel_y, yaw_diff)

        # Dibujar ejes de los marcadores seleccionados
        try:
            cv2.drawFrameAxes(display_frame, self.camera_matrix, self.dist_coeffs, 
                            rvec_ref, t_ref, self.marker_length_m * 0.6)
            cv2.drawFrameAxes(display_frame, self.camera_matrix, self.dist_coeffs, 
                            rvec_other, t_other, self.marker_length_m * 0.6)
        except Exception:
            pass

        self.get_logger().info(f"Published -> Δx: {rel_x:.3f} m, Δy: {rel_y:.3f} m, Δθ: {math.degrees(yaw_diff):.2f}° (ref ID={ref_id}, other ID={other_id})")

        # Mostrar frame con información
        self._show_frame(display_frame, num_markers, ids_list)

    def _show_frame(self, frame, num_markers, ids_list):
        """Muestra el frame con información de marcadores detectados."""
        # Añadir información de texto en la imagen
        h, w = frame.shape[:2]
        
        # Fondo semi-transparente para el texto
        overlay = frame.copy()
        cv2.rectangle(overlay, (10, 10), (400, 120), (0, 0, 0), -1)
        cv2.addWeighted(overlay, 0.6, frame, 0.4, 0, frame)
        
        # Texto con número de marcadores
        text = f"Marcadores detectados: {num_markers}"
        cv2.putText(frame, text, (20, 40), cv2.FONT_HERSHEY_SIMPLEX, 
                   0.7, (0, 255, 0), 2, cv2.LINE_AA)
        
        # Mostrar IDs de marcadores detectados
        if ids_list:
            ids_text = f"IDs: {', '.join(map(str, ids_list))}"
            cv2.putText(frame, ids_text, (20, 70), cv2.FONT_HERSHEY_SIMPLEX, 
                       0.6, (0, 255, 255), 2, cv2.LINE_AA)
        
        # Mostrar marcador de referencia
        if self.reference_marker_id is not None:
            ref_text = f"Referencia (0): ID {self.reference_marker_id}"
            cv2.putText(frame, ref_text, (20, 95), cv2.FONT_HERSHEY_SIMPLEX, 
                       0.5, (255, 255, 0), 2, cv2.LINE_AA)
        
        # Estado de publicación
        status = "PUBLICANDO" if num_markers >= 2 else "ESPERANDO 2 MARCADORES"
        color = (0, 255, 0) if num_markers >= 2 else (0, 165, 255)
        cv2.putText(frame, status, (20, 115), cv2.FONT_HERSHEY_SIMPLEX, 
                   0.5, color, 2, cv2.LINE_AA)
        
        # Mostrar ventana
        try:
            cv2.imshow("Camara IP - ArUco", frame)
            cv2.waitKey(1)
        except Exception as e:
            self.get_logger().debug(f"Error mostrando ventana: {e}")

    def _publish_pose2d(self, x, y, theta):
        msg = Pose2D()
        msg.x = float(x)
        msg.y = float(y)
        msg.theta = float(theta)  # radianes (Δθ)
        self.publisher_pose2d.publish(msg)

    @staticmethod
    def rotation_matrix_to_euler(R):
        """Convierte matriz de rotación 3x3 a (roll,pitch,yaw) en RADIÁNES."""
        sy = math.sqrt(R[0,0] * R[0,0] + R[1,0] * R[1,0])
        singular = sy < 1e-6
        if not singular:
            roll = math.atan2(R[2,1], R[2,2])
            pitch = math.atan2(-R[2,0], sy)
            yaw = math.atan2(R[1,0], R[0,0])
        else:
            roll = math.atan2(-R[1,2], R[1,1])
            pitch = math.atan2(-R[2,0], sy)
            yaw = 0.0
        return roll, pitch, yaw

    def destroy_node(self):
        try:
            self.mjpeg.stop()
        except Exception:
            pass
        super().destroy_node()

def main(args=None):
    rclpy.init(args=args)
    node = ArucoCamPose2DNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        try:
            node.destroy_node()
        except Exception:
            pass
        cv2.destroyAllWindows()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
