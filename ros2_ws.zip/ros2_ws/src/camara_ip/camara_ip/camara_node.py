#!/usr/bin/env python3
import sys
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Pose2D
from cv_bridge import CvBridge
import cv2
import cv2.aruco as aruco
import numpy as np
import math
import requests
import threading
import time

class MJPEGClient:
    """
    Lector robusto de streams MJPEG vía HTTP.
    Corre en un hilo y mantiene self.frame (BGR numpy) con el último JPEG decodificado.
    """
    def __init__(self, url, reconnect_delay=1.0, timeout=10.0):
        self.url = url
        self.reconnect_delay = reconnect_delay
        self.timeout = timeout
        self._thread = None
        self._stop_event = threading.Event()
        self._frame_lock = threading.Lock()
        self.frame = None  # numpy BGR
        self._running = False

    def start(self):
        if self._thread and self._thread.is_alive():
            return
        self._stop_event.clear()
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()
        self._running = True

    def stop(self):
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=1.0)
        self._running = False

    def _run(self):
        while not self._stop_event.is_set():
            try:
                with requests.get(self.url, stream=True, timeout=self.timeout) as r:
                    if r.status_code != 200:
                        time.sleep(self.reconnect_delay)
                        continue

                    buff = b''
                    for chunk in r.iter_content(chunk_size=1024):
                        if self._stop_event.is_set():
                            break
                        if not chunk:
                            continue
                        buff += chunk
                        while True:
                            soi = buff.find(b'\xff\xd8')
                            if soi == -1:
                                break
                            eoi = buff.find(b'\xff\xd9', soi + 2)
                            if eoi == -1:
                                if len(buff) > 5_000_000:
                                    buff = buff[soi:]
                                break
                            jpg = buff[soi:eoi + 2]
                            buff = buff[eoi + 2:]
                            arr = np.frombuffer(jpg, dtype=np.uint8)
                            img = cv2.imdecode(arr, cv2.IMREAD_COLOR)
                            if img is not None:
                                with self._frame_lock:
                                    self.frame = img
            except (requests.exceptions.RequestException, Exception):
                time.sleep(self.reconnect_delay)
                continue

    def get_frame(self):
        with self._frame_lock:
            if self.frame is None:
                return None
            return self.frame.copy()


class ArucoCamPose2DNode(Node):
    """
    Nodo que publica geometry_msgs/Pose2D en /aruco/pose2d con:
      - x, y: posición del marcador derecho relativa al marcador izquierdo (m)
      - theta: diferencia angular yaw_right - yaw_left (rad, normalizado)
    Publica a 10 Hz; si no hay 2 marcadores re-publica el último valor válido.
    
    CORRECCIÓN DE PERSPECTIVA: Calcula las posiciones reales en el plano 3D de los marcadores,
    compensando la inclinación de la cámara.
    """
    def __init__(self):
        super().__init__('aruco_pose2d_node')

        # Publisher único: Pose2D con x,y,theta (theta en radianes)
        self.publisher_pose2d = self.create_publisher(Pose2D, 'aruco/pose2d', 10)

        # Timer: 0.1s => 10 Hz
        self.timer_period = 0.1
        self.timer = self.create_timer(self.timer_period, self.timer_callback)

        # CV bridge
        self.bridge = CvBridge()

        # URL de la cámara IP
        self.url = "http://192.168.1.14:8080/video"

        # Cliente MJPEG robusto
        self.mjpeg = MJPEGClient(self.url, reconnect_delay=1.0, timeout=10.0)
        self.mjpeg.start()
        self.get_logger().info(f"Iniciando lector MJPEG para {self.url}")

        # ArUco
        self.aruco_dict = aruco.Dictionary_get(aruco.DICT_4X4_50)
        self.aruco_params = aruco.DetectorParameters_create()

        # Parámetros de cámara (reemplaza con calibración real)
        self.camera_matrix = np.array([[800.0,   0.0, 320.0],
                                       [  0.0, 800.0, 240.0],
                                       [  0.0,   0.0,   1.0]], dtype=np.float64)
        self.dist_coeffs = np.zeros((5, 1), dtype=np.float64)
        self.marker_length_m = 0.1

        # Último valor relativo válido (x, y, yaw)
        self.last_rel_x = 0.0
        self.last_rel_y = 0.0
        self.last_rel_yaw = 0.0
        self.has_valid_detection = False
        
        # Marcador de referencia
        self.reference_marker_id = None

    def compute_marker_world_pose(self, rvec, tvec):
        """
        Convierte la pose del marcador (rvec, tvec) desde coordenadas de cámara
        a coordenadas del mundo del marcador.
        
        Retorna:
        - position_world: posición 3D en el mundo (origen en el marcador)
        - R_world: matriz de rotación del marcador en el mundo
        """
        R_cam, _ = cv2.Rodrigues(rvec)
        
        # La posición del marcador en el mundo es simplemente tvec
        # (la cámara ve al marcador en tvec)
        position_world = tvec.reshape(3,)
        
        return position_world, R_cam

    def compute_relative_pose_corrected(self, pos_ref, R_ref, pos_other, R_other):
        """
        Calcula la posición relativa del marcador 'other' respecto al marcador 'ref'
        en el sistema de coordenadas LOCAL del marcador de referencia.
        
        Esta es la corrección clave: proyectamos ambos marcadores al mismo plano 3D
        y calculamos la distancia real entre ellos.
        
        Args:
        - pos_ref: posición 3D del marcador de referencia en coords de cámara
        - R_ref: matriz de rotación del marcador de referencia
        - pos_other: posición 3D del otro marcador en coords de cámara
        - R_other: matriz de rotación del otro marcador
        
        Returns:
        - rel_x, rel_y, rel_z: posición relativa en el sistema del marcador de referencia
        - yaw_diff: diferencia de orientación (yaw)
        """
        # Vector de desplazamiento en coordenadas de cámara
        delta_t = pos_other - pos_ref
        
        # Transformar al sistema de coordenadas del marcador de referencia
        # Esto elimina el efecto de la perspectiva de la cámara
        t_rel = R_ref.T.dot(delta_t)
        
        # Calcular la rotación relativa
        R_rel = R_ref.T.dot(R_other)
        
        # Para mayor precisión, también podemos calcular la distancia euclídea real
        # en el espacio 3D (distancia entre centros de marcadores)
        distance_3d = np.linalg.norm(delta_t)
        
        rel_x = float(t_rel[0])
        rel_y = float(t_rel[1])
        rel_z = float(t_rel[2])
        
        # Calcular diferencia de yaw en el plano XY del marcador de referencia
        roll_ref, pitch_ref, yaw_ref = self.rotation_matrix_to_euler(R_ref)
        roll_other, pitch_other, yaw_other = self.rotation_matrix_to_euler(R_other)
        
        yaw_diff = yaw_other - yaw_ref
        yaw_diff = math.atan2(math.sin(yaw_diff), math.cos(yaw_diff))
        
        return rel_x, rel_y, rel_z, yaw_diff, distance_3d

    def compute_planar_distance(self, pos_ref, R_ref, pos_other, R_other):
        """
        Calcula la distancia en el plano de los marcadores, asumiendo que ambos
        están en el mismo plano (lo cual es típico en configuraciones de robots).
        
        Esta función proyecta ambos marcadores al plano promedio y calcula
        la distancia real en ese plano, eliminando distorsiones de perspectiva.
        """
        # Calcular los vectores normales al plano de cada marcador
        # El eje Z de cada marcador apunta perpendicular al marcador
        normal_ref = R_ref[:, 2]  # Tercera columna = eje Z
        normal_other = R_other[:, 2]
        
        # Plano promedio (asumiendo que están aproximadamente coplanares)
        avg_normal = (normal_ref + normal_other) / 2.0
        avg_normal = avg_normal / np.linalg.norm(avg_normal)
        
        # Proyectar el vector de desplazamiento al plano
        delta_t = pos_other - pos_ref
        
        # Componente del desplazamiento en el plano
        # (eliminamos la componente perpendicular al plano)
        displacement_perpendicular = np.dot(delta_t, avg_normal) * avg_normal
        displacement_in_plane = delta_t - displacement_perpendicular
        
        # Distancia en el plano
        planar_distance = np.linalg.norm(displacement_in_plane)
        
        # Transformar al sistema de coordenadas del marcador de referencia
        displacement_in_ref = R_ref.T.dot(displacement_in_plane)
        
        return displacement_in_ref[0], displacement_in_ref[1], planar_distance

    def timer_callback(self):
        # Obtener último frame desde MJPEGClient
        frame = self.mjpeg.get_frame()
        if frame is None:
            self.get_logger().debug("No hay frame aún; re-publicando último valor conocido.")
            self._publish_pose2d(self.last_rel_x, self.last_rel_y, self.last_rel_yaw)
            return

        # Crear copia para dibujar
        display_frame = frame.copy()

        # Procesar frame
        try:
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        except Exception as e:
            self.get_logger().warn(f"Error convert to gray: {e}; re-publicando último valor")
            self._publish_pose2d(self.last_rel_x, self.last_rel_y, self.last_rel_yaw)
            self._show_frame(display_frame, 0, [])
            return

        corners, ids, _ = aruco.detectMarkers(gray, self.aruco_dict, parameters=self.aruco_params)

        # Número de marcadores detectados
        num_markers = 0 if ids is None else len(ids)
        ids_list = [] if ids is None else [int(i[0]) if isinstance(i, (list, np.ndarray)) else int(i) for i in ids]

        # Dibujar marcadores detectados en el frame
        if ids is not None and len(ids) > 0:
            aruco.drawDetectedMarkers(display_frame, corners, ids)

        # Establecer marcador de referencia
        if num_markers >= 1:
            if self.reference_marker_id is None:
                self.reference_marker_id = ids_list[0]
                self.get_logger().info(f"Marcador de referencia establecido: ID={self.reference_marker_id}")
            elif num_markers >= 2:
                min_id = min(ids_list)
                if min_id < self.reference_marker_id:
                    self.reference_marker_id = min_id
                    self.get_logger().info(f"Marcador de referencia actualizado a menor ID: {self.reference_marker_id}")
        
        # Procesar solo si hay 2 o más marcadores
        if num_markers < 2:
            if not self.has_valid_detection:
                self.get_logger().debug(f"Detectados {num_markers} marcador(es); se necesitan 2. Publicando ceros.")
            else:
                self.get_logger().debug(f"Detectados {num_markers} marcador(es); re-publicando último valor válido.")
            self._publish_pose2d(self.last_rel_x, self.last_rel_y, self.last_rel_yaw)
            self._show_frame(display_frame, num_markers, ids_list)
            return

        # Estimar pose de cada marcador
        rvecs, tvecs, _ = aruco.estimatePoseSingleMarkers(corners, self.marker_length_m,
                                                          self.camera_matrix, self.dist_coeffs)

        N = len(ids)
        rvecs_np = np.reshape(rvecs, (N, 3))
        tvecs_np = np.reshape(tvecs, (N, 3))

        # Selección del marcador de referencia y el otro
        ref_idx = None
        other_idx = None
        
        for i, marker_id in enumerate(ids_list):
            if marker_id == self.reference_marker_id:
                ref_idx = i
            elif other_idx is None:
                other_idx = i
        
        if ref_idx is None:
            ref_idx = ids_list.index(min(ids_list))
            self.reference_marker_id = ids_list[ref_idx]
        
        if other_idx is None:
            if ref_idx == 0 and len(ids_list) > 1:
                other_idx = 1
            else:
                other_idx = 0 if ref_idx != 0 else 1
        
        ref_id = ids_list[ref_idx]
        other_id = ids_list[other_idx]

        # Obtener poses
        t_ref = tvecs_np[ref_idx].reshape(3,)
        rvec_ref = rvecs_np[ref_idx].reshape(3,)
        R_ref, _ = cv2.Rodrigues(rvec_ref)

        t_other = tvecs_np[other_idx].reshape(3,)
        rvec_other = rvecs_np[other_idx].reshape(3,)
        R_other, _ = cv2.Rodrigues(rvec_other)

        # MÉTODO 1: Transformación directa (más precisa en general)
        rel_x, rel_y, rel_z, yaw_diff, dist_3d = self.compute_relative_pose_corrected(
            t_ref, R_ref, t_other, R_other
        )
        
        # MÉTODO 2: Proyección planar (útil si los marcadores están en el mismo plano)
        # Puedes descomentar esto para comparar resultados
        # planar_x, planar_y, planar_dist = self.compute_planar_distance(
        #     t_ref, R_ref, t_other, R_other
        # )
        # self.get_logger().info(f"Distancia planar: {planar_dist:.3f} m (x:{planar_x:.3f}, y:{planar_y:.3f})")

        # Guardar último valor válido
        self.last_rel_x = rel_x
        self.last_rel_y = rel_y
        self.last_rel_yaw = yaw_diff
        self.has_valid_detection = True

        # Publicar Pose2D (x,y,theta)
        self._publish_pose2d(rel_x, rel_y, yaw_diff)

        # Dibujar ejes
        try:
            cv2.drawFrameAxes(display_frame, self.camera_matrix, self.dist_coeffs, 
                            rvec_ref, t_ref, self.marker_length_m * 0.6)
            cv2.drawFrameAxes(display_frame, self.camera_matrix, self.dist_coeffs, 
                            rvec_other, t_other, self.marker_length_m * 0.6)
        except Exception:
            pass

        # Calcular distancia euclídea 2D (en el plano XY del marcador de referencia)
        dist_2d = math.sqrt(rel_x**2 + rel_y**2)
        
        self.get_logger().info(
            f"Published -> Δx: {rel_x:.3f} m, Δy: {rel_y:.3f} m, "
            f"Dist2D: {dist_2d:.3f} m, Dist3D: {dist_3d:.3f} m, "
            f"Δθ: {math.degrees(yaw_diff):.2f}° (ref ID={ref_id}, other ID={other_id})"
        )

        # Mostrar frame con información
        self._show_frame(display_frame, num_markers, ids_list, rel_x, rel_y, dist_2d, yaw_diff)

    def _show_frame(self, frame, num_markers, ids_list, rel_x=None, rel_y=None, dist=None, yaw=None):
        """Muestra el frame con información de marcadores detectados."""
        h, w = frame.shape[:2]
        
        # Fondo semi-transparente para el texto
        overlay = frame.copy()
        box_height = 180 if rel_x is not None else 120
        cv2.rectangle(overlay, (10, 10), (450, box_height), (0, 0, 0), -1)
        cv2.addWeighted(overlay, 0.6, frame, 0.4, 0, frame)
        
        # Texto con número de marcadores
        text = f"Marcadores detectados: {num_markers}"
        cv2.putText(frame, text, (20, 40), cv2.FONT_HERSHEY_SIMPLEX, 
                   0.7, (0, 255, 0), 2, cv2.LINE_AA)
        
        # Mostrar IDs de marcadores detectados
        if ids_list:
            ids_text = f"IDs: {', '.join(map(str, ids_list))}"
            cv2.putText(frame, ids_text, (20, 70), cv2.FONT_HERSHEY_SIMPLEX, 
                       0.6, (0, 255, 255), 2, cv2.LINE_AA)
        
        # Mostrar marcador de referencia
        if self.reference_marker_id is not None:
            ref_text = f"Referencia (0): ID {self.reference_marker_id}"
            cv2.putText(frame, ref_text, (20, 95), cv2.FONT_HERSHEY_SIMPLEX, 
                       0.5, (255, 255, 0), 2, cv2.LINE_AA)
        
        # Estado de publicación
        status = "PUBLICANDO" if num_markers >= 2 else "ESPERANDO 2 MARCADORES"
        color = (0, 255, 0) if num_markers >= 2 else (0, 165, 255)
        cv2.putText(frame, status, (20, 115), cv2.FONT_HERSHEY_SIMPLEX, 
                   0.5, color, 2, cv2.LINE_AA)
        
        # Mostrar mediciones relativas si están disponibles
        if rel_x is not None:
            meas_text = f"X:{rel_x:.3f}m Y:{rel_y:.3f}m D:{dist:.3f}m"
            cv2.putText(frame, meas_text, (20, 145), cv2.FONT_HERSHEY_SIMPLEX, 
                       0.5, (255, 255, 255), 2, cv2.LINE_AA)
            
            angle_text = f"Angulo: {math.degrees(yaw):.1f} grados"
            cv2.putText(frame, angle_text, (20, 170), cv2.FONT_HERSHEY_SIMPLEX, 
                       0.5, (255, 255, 255), 2, cv2.LINE_AA)
        
        # Mostrar ventana
        try:
            cv2.imshow("Camara IP - ArUco (Corregido)", frame)
            cv2.waitKey(1)
        except Exception as e:
            self.get_logger().debug(f"Error mostrando ventana: {e}")

    def _publish_pose2d(self, x, y, theta):
        msg = Pose2D()
        msg.x = float(x)
        msg.y = float(y)
        msg.theta = float(theta)
        self.publisher_pose2d.publish(msg)

    @staticmethod
    def rotation_matrix_to_euler(R):
        """Convierte matriz de rotación 3x3 a (roll,pitch,yaw) en RADIANES."""
        sy = math.sqrt(R[0,0] * R[0,0] + R[1,0] * R[1,0])
        singular = sy < 1e-6
        if not singular:
            roll = math.atan2(R[2,1], R[2,2])
            pitch = math.atan2(-R[2,0], sy)
            yaw = math.atan2(R[1,0], R[0,0])
        else:
            roll = math.atan2(-R[1,2], R[1,1])
            pitch = math.atan2(-R[2,0], sy)
            yaw = 0.0
        return roll, pitch, yaw

    def destroy_node(self):
        try:
            self.mjpeg.stop()
        except Exception:
            pass
        super().destroy_node()

def main(args=None):
    rclpy.init(args=args)
    node = ArucoCamPose2DNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        try:
            node.destroy_node()
        except Exception:
            pass
        cv2.destroyAllWindows()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
