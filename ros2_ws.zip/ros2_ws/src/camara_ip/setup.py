from setuptools import setup

package_name = 'camara_ip'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='juan-manuel',
    maintainer_email='tu_correo@example.com',
    description='Nodo para acceder a la cámara IP con ROS 2 y OpenCV',
    license='Apache License 2.0',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'camara_node = camara_ip.camara_node:main'
        ],
    },
)

